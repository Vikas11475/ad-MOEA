function Ranks = F_sortrank(FrontNo,WSRANK,CWD,N)
%% combining Front number with sum of the objectives
Fitness1   = [FrontNo', WSRANK];

Rank1                = 1 : 1 : N;
[~,index1]           = sortrows(Fitness1);

for i = 1 : N
   Rank1(index1(i)) = i;
end

%% combining Front number with Crowding distance
Fitness2   = [FrontNo',-CWD'];

Rank2                = 1 : 1 : N;
[~,index2]           = sortrows(Fitness2);

for i = 1 : N
   Rank2(index2(i)) = i;
end

%%Final ranks
Ranks = [Rank1', Rank2'];

% SRANK = sum(AAA,2);
    
end