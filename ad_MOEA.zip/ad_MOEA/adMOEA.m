classdef adMOEA < ALGORITHM
% <multi> <many> <real/binary/permutation> <constrained/none>
% adaptive mating and environmental selection

%------------------------------- Reference --------------------------------
% V. Palakonda and R. Mallipeddi, "An evolutionary algorithm for multi and many-objective optimization with 
% adaptive mating and environmental selection," IEEE Access, vol. 8, pp. 82781-82796, May 2020.
%------------------------------- Copyright --------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population    = Problem.Initialization();
            FrontNo       = NDSort(Population.objs,inf);
            r             = 1;
            %% Optimization
            while Algorithm.NotTerminated(Population)
                MatingPool = MatingSelection(Population.objs,FrontNo,r);
                Offspring  = OperatorGA(Population(MatingPool));
                [Population,FrontNo,r] = EnvironmentalSelection([Population,Offspring],Problem.N,r);
            end
        end
    end
end