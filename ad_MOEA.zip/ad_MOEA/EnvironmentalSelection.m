function [Population,FrontNo,r] = EnvironmentalSelection(Population,N,r)
%% The environmental selection of ad-MOEA
PopObj   = Population.objs;
%% Non-dominated sorting
[FrontNo,MaxFNo]    = NDSort(PopObj,N);
Next                = FrontNo < MaxFNo;
Last                = find(FrontNo==MaxFNo);

%% Calculating the Probability
Im                  = length(find(FrontNo==1))/length(FrontNo);
M                   = size(PopObj,2);
Imp                 = Im.^(1/M);
r                   = 0.99*r + 0.01*(1-Imp); % probability

Choose              = LastSelection(PopObj(Last,:),N-sum(Next),r);
Next(Last(Choose==1))  = true;

%% Population for next generation
Population = Population(Next);
FrontNo    = FrontNo(Next);

%% Selecting the solutions in critical front

    function Choose = LastSelection(PopObj_Last,K,r)
        
        N1          = size(PopObj_Last,1);
        Choose      = zeros(N1,1);
        
        %% Selection based on Sum of the objectives
        WS_L        = F_WSRank(PopObj_Last);  % Calculate the Sum of the Objective values
        [~,Rank_WS] = sort(WS_L);
        k1          = ceil(K*r);
        KK          = Rank_WS(1 : k1);
        Choose(KK)  = true;                   % Select the solutions based on sum of the objectives
        %% Selection based on Crowding distance
        YY          = find(Choose == false);
        PopObj_rem  = PopObj_Last(YY,:);
        NN          = size(PopObj_rem,1);
        Fno         = ones(NN,1);
        CWD         = CrowdingDistance(PopObj_rem,Fno);    % Calculate the Crowding Distance
        
        [~,Rank1]                          = sort(CWD','descend');
        Choose(YY(Rank1(1:K-sum(Choose)))) = true;     % Select the solutions based on Crowding Distance
    end
end