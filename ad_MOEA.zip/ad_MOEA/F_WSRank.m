function WSRANK = F_WSRank(PopObj)

%% This function calcualtes the sum of the normalized objectives metrics
        [N,~]            = size(PopObj);  
        fmax             = repmat(max(PopObj,[],1),N,1);
        fmin             = repmat(min(PopObj,[],1),N,1);
        PopObj           = (PopObj-fmin)./(fmax-fmin);
        [WSRANK]          = sum(PopObj,2);    
end